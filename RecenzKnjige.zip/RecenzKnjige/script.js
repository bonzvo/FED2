
function addReview() {
let bookName = document.getElementById("bookName").value.trim();
let bookRating = document.getElementById("bookRating").value.trim();

if (!bookName || bookRating < 1 || bookRating > 10) {
alert("Unesite ispravan naziv knjige i ocjenu od 1 do 10.");
return;
}

let reviewsContainer = document.getElementById("reviewsContainer");
let reviewDiv = document.createElement("div");
reviewDiv.classList.add("review");

let timestamp = new Date().toLocaleString();

reviewDiv.innerHTML = `
<div>
<strong>${bookName}</strong> (Ocjena: ${bookRating}) <br>
<small>${timestamp}</small>
</div>
<div>
<button onclick="toggleFavorite(this)">Favorit</button>
<button onclick="deleteReview(this)">Briši</button>
</div>
`;

reviewsContainer.appendChild(reviewDiv);

// Reset polja
document.getElementById("bookName").value = ""
document.getElementById("bookRating").value = ""
}

function toggleFavorite(button) {
let reviewDiv = button.closest(".review");
reviewDiv.classList.toggle("favorite");
}

function deleteReview(button) {
let reviewDiv = button.closest(".review");
reviewDiv.remove();
}